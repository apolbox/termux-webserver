#!/usr/bin/sh

php index.php "http://localhost:8080/Tugas.zip"