<?php
/**
 * File index untuk menjalankan downloading
 *
 * @author Ayus Irfang Filaras
 * @license Apache-2.0
 * @version v1.0
 */
require(dirname(__FILE__) . '/bootstrap.php');
require(dirname(__FILE__) . '/request.php');

function parseRequest($url) {
    exec("curl -si \
        -H 'Authorization: token fb27618772a83e932709bfd62689323886f8a070' \
        $url", $info);
        
    return array_map(function($urlDownload){
        
        if (preg_match("/Location: /", $urlDownload, $m)) {
            return str_replace($m[0], "", $urlDownload);
        }
        
    }, array_values($info));
}

$uri = isset($argv[1]) ? $argv[1] : "";
$parseUri = parseRequest($uri);
$url = "";

foreach ($parseUri as $k => $v) {
    if (empty($v)) {
        unset($parseUri[$k]);
        continue;
    }
    $url = $parseUri[$k];
}

return start_download($url);