<?php
/**
 * File index untuk menjalankan downloading
 *
 * @author Ayus Irfang Filaras
 * @license Apache-2.0
 * @version v1.0
 */
require(dirname(__FILE__) . '/bootstrap.php');
require(dirname(__FILE__) . '/request.php');

start_download();
